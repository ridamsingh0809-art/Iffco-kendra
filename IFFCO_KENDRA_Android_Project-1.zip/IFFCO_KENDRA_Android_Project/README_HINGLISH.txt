IFFCO KENDRA Android project (reconstructed from the APK you uploaded)

KYA CHANGE KIYA HAI
1. App ka visible naam IFFCO KENDRA kar diya hai.
2. Existing product catalog, cart aur WhatsApp order message flow ko rakha hai.
3. Android WebView mein WhatsApp link handler add kiya hai. Ab wa.me link pehle WhatsApp app, phir WhatsApp Business ko open karne ki koshish karega; agar dono available na hon to Android ka normal link handler chalega.
4. Firebase/Firestore add nahi kiya.

IMPORTANT LIMITATION
Aapki uploaded APK mein original complete Android source project nahi tha; usmein HTML asset aur compiled Android files the. Isliye yeh original ZIP ka exact duplicate nahi hai. Yeh us APK ke HTML app ko preserve karke banaya gaya naya, minimal Android WebView project hai. APK mein jo features HTML ke andar the woh rakhe gaye hain.

LINUX PAR BUILD (Chromebook Linux)
- Android SDK aur JDK 17 required hain.
- Android Studio available ho to: ZIP extract karein, Android Studio mein extracted IFFCO_KENDRA_Android_Project folder open karein, Gradle sync complete hone dein, phir Build > Build APK(s) select karein.
- Android SDK mein Android SDK Platform 35 aur Build Tools install hone chahiye.
- Terminal se build karne ke liye Gradle 8.7 install/download karke project folder mein `gradle assembleDebug` chalayein.
- APK output: app/build/outputs/apk/debug/app-debug.apk

WHATSAPP CHECK
- Phone/emulator par WhatsApp ya WhatsApp Business installed hona chahiye.
- Agar browser/WhatsApp app link-handling settings override kar rahi hain, Android Settings > Apps > WhatsApp > Open by default mein supported links allow karein.
- Agar WhatsApp installed nahi hai, to browser ya system link handler open ho sakta hai.

CONTACT / ORDER NUMBER
HTML mein original WhatsApp number 7985849729 ko preserve kiya gaya hai. Agar order kisi doosre number par bhejna hai, app/src/main/assets/index.html mein PHONE constant update karein (country code ke saath, jaise India ke liye 91 + 10-digit number).
